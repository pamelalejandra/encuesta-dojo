from flask import Flask, render_template, request, redirect,session
app = Flask(__name__)
app.secret_key = 'root'

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/process', methods=['POST'])
def process():
    session['username']= request.form['first_name']
    session['place'] = request.form['location']
    session['elegido'] = request.form['favorite']
    session['publicacion'] = request.form['comment']
    return redirect('/result')

@app.route('/result')
def result():
    print(request.form)
    return render_template('result.html', first_name_on_template = session['username'], location_on_template = session['place'], favorite_on_template = session['elegido'], comment_on_template = session['publicacion'])

@app.errorhandler(404)
def page_not_found(e):
    return 'Pagina no encontrada'

if __name__ == "__main__":
    app.run(debug=True)